import json,os,pathlib,subprocess,sys
engine,output=sys.argv[1:]
error=open(pathlib.Path(output)/'engine.stderr','wb')
child=subprocess.Popen([engine,'query-session'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=error,process_group=0)
pathlib.Path(output,'ready.json').write_text(json.dumps({'parent':os.getpid(),'query':child.pid,'group':os.getpgid(child.pid)}))
# Deliberately retain Popen without poll(), wait(), communicate(), or another child spawn.
sys.stdin.readline()
os._exit(0)
