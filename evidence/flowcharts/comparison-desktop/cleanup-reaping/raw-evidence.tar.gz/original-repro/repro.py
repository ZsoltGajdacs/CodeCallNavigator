"""Read-only ownership diagnosis with the actual packaged query-session binary."""
import errno
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

sys.path.insert(0, str(Path('/private/tmp/codecallnavigator-task22.6/tools')))
from comparison_desktop_cleanup import cleanup_queries, group_alive, query_leases

OUTPUT = Path('/private/tmp/codecallnavigator-task22.6/target/unit4-verification/native-unreaped-parent')
ENGINE = Path('/private/tmp/flow-comparison-native-ofmwr47a/Relocated CodeCallNavigator.app/Contents/MacOS/codecallnavigator-engine')
PARENT = OUTPUT / 'parent.py'
PARENT.write_text('''import json,os,pathlib,subprocess,sys
engine,output=sys.argv[1:]
error=open(pathlib.Path(output)/'engine.stderr','wb')
child=subprocess.Popen([engine,'query-session'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=error,process_group=0)
pathlib.Path(output,'ready.json').write_text(json.dumps({'parent':os.getpid(),'query':child.pid,'group':os.getpgid(child.pid)}))
# Deliberately retain Popen without poll(), wait(), communicate(), or another child spawn.
sys.stdin.readline()
os._exit(0)
''')
origin = time.monotonic()
events = []
stop = threading.Event()
parent = subprocess.Popen([sys.executable, str(PARENT), str(ENGINE), str(OUTPUT)], stdin=subprocess.PIPE)
identity = None
leases = []


def snapshot(label):
    result = subprocess.run(['/bin/ps', '-ww', '-axo', 'pid=,ppid=,pgid=,stat=,command='],
                            capture_output=True, text=True, check=True, timeout=5)
    rows = []
    for line in result.stdout.splitlines():
        fields = line.split(None, 4)
        if len(fields) == 5:
            pid, ppid, group = map(int, fields[:3])
            if pid == parent.pid or group == identity['group']:
                rows.append({'pid': pid, 'ppid': ppid, 'pgid': group, 'stat': fields[3], 'command': fields[4]})
    event = {'label': label, 'elapsed_ms': (time.monotonic() - origin) * 1000, 'rows': rows}
    events.append(event)
    return event


def sample():
    previous = None
    while not stop.is_set():
        event = snapshot('transition')
        signature = [(row['pid'], row['ppid'], row['pgid'], row['stat'], row['command']) for row in event['rows']]
        if signature == previous:
            events.pop()
        previous = signature
        stop.wait(0.025)


report = {'engine': str(ENGINE), 'helper_pid': os.getpid(), 'execution': 'require_escalated; actual packaged query-session; no GUI/window/build/analysis'}
try:
    deadline = time.monotonic() + 5
    while not (OUTPUT / 'ready.json').exists():
        assert parent.poll() is None
        assert time.monotonic() < deadline
        time.sleep(0.01)
    identity = json.loads((OUTPUT / 'ready.json').read_text())
    leases = query_leases(parent, ENGINE)
    assert len(leases) == 1 and leases[0].pid == identity['query']
    report['identity'] = identity
    snapshot('before_cleanup')
    sampler = threading.Thread(target=sample)
    sampler.start()
    try:
        report['cleanup_result'] = cleanup_queries(parent, ENGINE, lambda: None)
    except Exception as error:
        report['cleanup_error'] = str(error)
    snapshot('after_cleanup_while_parent_retains_unreaped_child')
    report['parent_still_alive'] = parent.poll() is None
    report['group_still_present'] = group_alive(identity['group'])
    try:
        report['helper_waitpid_result'] = os.waitpid(identity['query'], os.WNOHANG)
    except ChildProcessError as error:
        report['helper_waitpid_error'] = {'errno': error.errno, 'name': errno.errorcode.get(error.errno), 'message': str(error)}
    parent.stdin.write(b'exit\n')
    parent.stdin.flush()
    report['parent_exit_code'] = parent.wait(timeout=5)
    snapshot('immediately_after_parent_exit_and_helper_wait')
    deadline = time.monotonic() + 3
    while group_alive(identity['group']) and time.monotonic() < deadline:
        time.sleep(0.025)
    snapshot('final_after_parent_exit')
    report['final_group_present'] = group_alive(identity['group'])
finally:
    stop.set()
    if 'sampler' in locals():
        sampler.join(timeout=5)
    if parent.poll() is None:
        parent.terminate()
        parent.wait(timeout=5)
    report['events'] = events
    (OUTPUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
