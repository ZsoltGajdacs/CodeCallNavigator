import json,os,pathlib,subprocess,sys
engine,output=sys.argv[1:]
child=subprocess.Popen([engine,'query-session'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,process_group=0)
pathlib.Path(output,'ready.json').write_text(json.dumps({'parent':os.getpid(),'query':child.pid,'group':os.getpgid(child.pid)}))
# Intentionally never poll/wait/reap this child.
sys.stdin.readline()
os._exit(0)
