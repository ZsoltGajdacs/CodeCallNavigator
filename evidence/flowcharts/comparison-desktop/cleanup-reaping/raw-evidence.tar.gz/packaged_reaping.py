"""Observe the approved two-stage fix with the actual preserved candidate engine."""
import json
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()/'tools'))
from comparison_desktop_cleanup import OwnedRun,group_alive,query_leases
output=Path.cwd()/'target/unit4-cleanup-reaping/packaged'
output.mkdir(exist_ok=True)
engine=Path('/private/tmp/flow-comparison-native-ofmwr47a/Relocated CodeCallNavigator.app/Contents/MacOS/codecallnavigator-engine')
parent_script=output/'parent.py'
parent_script.write_text('''import json,os,pathlib,subprocess,sys
engine,output=sys.argv[1:]
child=subprocess.Popen([engine,'query-session'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,process_group=0)
pathlib.Path(output,'ready.json').write_text(json.dumps({'parent':os.getpid(),'query':child.pid,'group':os.getpgid(child.pid)}))
# Intentionally never poll/wait/reap this child.
sys.stdin.readline()
os._exit(0)
''')
parent=subprocess.Popen([sys.executable,str(parent_script),str(engine),str(output)],stdin=subprocess.PIPE)
identity=None
try:
 deadline=time.monotonic()+5
 while not(output/'ready.json').exists():
  assert parent.poll() is None and time.monotonic()<deadline
  time.sleep(0.01)
 identity=json.loads((output/'ready.json').read_text())
 leases=query_leases(parent,engine)
 assert len(leases)==1 and leases[0].pid==identity['query']
 gate=SimpleNamespace(project=output,observed=None,disarm=lambda:None)
 audit=OwnedRun(parent,engine,gate,output).close()
 assert audit['pre_parent']['status']=='awaiting_parent_reap'
 assert any(row['state'].startswith('Z') for snapshot in audit['pre_parent']['snapshots'] for row in snapshot['members'])
 assert audit['post_parent']['members']==[] and audit['post_parent']['status']=='cleared'
 assert parent.poll() is not None and not group_alive(identity['group'])
 result={'status':'passed','engine':str(engine),'identity':identity,'audit':audit,'execution':'outside sandbox; actual packaged engine; no native window/package/build/analysis'}
 (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
finally:
 if parent.poll() is None:
  parent.terminate();parent.wait(timeout=5)
